from django.apps import AppConfig


class ExcelformatterAppConfig(AppConfig):
    name = 'excelformatter_app'
